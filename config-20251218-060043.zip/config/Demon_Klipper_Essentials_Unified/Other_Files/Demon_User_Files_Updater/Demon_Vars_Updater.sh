

#!/bin/bash
# 3DPrintDemon Klipper Essentials Installer Demon_Vars_Updater Script v1.0.0
# Define
U="$USER"

cp -f /home/$U/printer_data/config/Demon_Klipper_Essentials_Unified/Other_Files/Demon_Vars/demon_vars.cfg /home/$U


echo "Operations complete."



