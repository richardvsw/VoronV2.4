

#!/bin/bash
# 3DPrintDemon Klipper Essentials Installer Demon_Vars Script v1.0.0
# Define
U="$USER"

cd /home/$U
wget https://raw.githubusercontent.com/3DPrintDemon/Demon_Klipper_Essentials_Unified/refs/heads/main/Other_Files/Demon_Vars/demon_vars.cfg -O demon_vars.cfg --backups=0


echo "Operations complete."



